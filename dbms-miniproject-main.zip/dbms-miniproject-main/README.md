# dbms-miniproject
This is dbms_miniproject. This project is an E-commerce Product Catalog website.
MongoDB database is used to store the data.
